﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 158,
              hour_array: ["chars_6A2CD342_000.png","chars_6A2CD342_001.png","chars_6A2CD342_002.png","chars_6A2CD342_003.png","chars_6A2CD342_004.png","chars_6A2CD342_005.png","chars_6A2CD342_006.png","chars_6A2CD342_007.png","chars_6A2CD342_008.png","chars_6A2CD342_009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 174,
              minute_startY: 158,
              minute_array: ["chars_935C0409_000.png","chars_935C0409_001.png","chars_935C0409_002.png","chars_935C0409_003.png","chars_935C0409_004.png","chars_935C0409_005.png","chars_935C0409_006.png","chars_935C0409_007.png","chars_935C0409_008.png","chars_935C0409_009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 320,
              second_startY: 212,
              second_array: ["chars_FA204DF7_000.png","chars_FA204DF7_001.png","chars_FA204DF7_002.png","chars_FA204DF7_003.png","chars_FA204DF7_004.png","chars_FA204DF7_005.png","chars_FA204DF7_006.png","chars_FA204DF7_007.png","chars_FA204DF7_008.png","chars_FA204DF7_009.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 67,
              font_array: ["chars_664502AB_000.png","chars_664502AB_001.png","chars_664502AB_002.png","chars_664502AB_003.png","chars_664502AB_004.png","chars_664502AB_005.png","chars_664502AB_006.png","chars_664502AB_007.png","chars_664502AB_008.png","chars_664502AB_009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'chars_664502AB_011.png',
              unit_tc: 'chars_664502AB_011.png',
              unit_en: 'chars_664502AB_011.png',
              negative_image: 'chars_664502AB_010.png',
              invalid_image: 'chars_664502AB_012.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 59,
              y: 57,
              image_array: ["set_5_85x85_meteo_1.png","set_5_85x85_meteo_2.png","set_5_85x85_meteo_3.png","set_5_85x85_meteo_4.png","set_5_85x85_meteo_5.png","set_5_85x85_meteo_6.png","set_5_85x85_meteo_7.png","set_5_85x85_meteo_8.png","set_5_85x85_meteo_9.png","set_5_85x85_meteo_10.png","set_5_85x85_meteo_11.png","set_5_85x85_meteo_12.png","set_5_85x85_meteo_13.png","set_5_85x85_meteo_14.png","set_5_85x85_meteo_15.png","set_5_85x85_meteo_16.png","set_5_85x85_meteo_17.png","set_5_85x85_meteo_18.png","set_5_85x85_meteo_19.png","set_5_85x85_meteo_20.png","set_5_85x85_meteo_21.png","set_5_85x85_meteo_22.png","set_5_85x85_meteo_23.png","set_5_85x85_meteo_24.png","set_5_85x85_meteo_25.png","set_5_85x85_meteo_26.png","set_5_85x85_meteo_27.png","set_5_85x85_meteo_28.png","set_5_85x85_meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 305,
              font_array: ["chars_77EB1E7C_000.png","chars_77EB1E7C_001.png","chars_77EB1E7C_002.png","chars_77EB1E7C_003.png","chars_77EB1E7C_004.png","chars_77EB1E7C_005.png","chars_77EB1E7C_006.png","chars_77EB1E7C_007.png","chars_77EB1E7C_008.png","chars_77EB1E7C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 176,
              y: 306,
              font_array: ["chars_9294F377_000.png","chars_9294F377_001.png","chars_9294F377_002.png","chars_9294F377_003.png","chars_9294F377_004.png","chars_9294F377_005.png","chars_9294F377_006.png","chars_9294F377_007.png","chars_9294F377_008.png","chars_9294F377_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 305,
              font_array: ["chars_77EB1E7C_000.png","chars_77EB1E7C_001.png","chars_77EB1E7C_002.png","chars_77EB1E7C_003.png","chars_77EB1E7C_004.png","chars_77EB1E7C_005.png","chars_77EB1E7C_006.png","chars_77EB1E7C_007.png","chars_77EB1E7C_008.png","chars_77EB1E7C_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 18,
              font_array: ["chars_26D96278_000.png","chars_26D96278_001.png","chars_26D96278_002.png","chars_26D96278_003.png","chars_26D96278_004.png","chars_26D96278_005.png","chars_26D96278_006.png","chars_26D96278_007.png","chars_26D96278_008.png","chars_26D96278_009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 104,
              day_startY: 356,
              day_sc_array: ["chars_579A37C3_000.png","chars_579A37C3_001.png","chars_579A37C3_002.png","chars_579A37C3_003.png","chars_579A37C3_004.png","chars_579A37C3_005.png","chars_579A37C3_006.png","chars_579A37C3_007.png","chars_579A37C3_008.png","chars_579A37C3_009.png"],
              day_tc_array: ["chars_579A37C3_000.png","chars_579A37C3_001.png","chars_579A37C3_002.png","chars_579A37C3_003.png","chars_579A37C3_004.png","chars_579A37C3_005.png","chars_579A37C3_006.png","chars_579A37C3_007.png","chars_579A37C3_008.png","chars_579A37C3_009.png"],
              day_en_array: ["chars_579A37C3_000.png","chars_579A37C3_001.png","chars_579A37C3_002.png","chars_579A37C3_003.png","chars_579A37C3_004.png","chars_579A37C3_005.png","chars_579A37C3_006.png","chars_579A37C3_007.png","chars_579A37C3_008.png","chars_579A37C3_009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 225,
              year_startY: 401,
              year_sc_array: ["chars_80EED7A6_000.png","chars_80EED7A6_001.png","chars_80EED7A6_002.png","chars_80EED7A6_003.png","chars_80EED7A6_004.png","chars_80EED7A6_005.png","chars_80EED7A6_006.png","chars_80EED7A6_007.png","chars_80EED7A6_008.png","chars_80EED7A6_009.png"],
              year_tc_array: ["chars_80EED7A6_000.png","chars_80EED7A6_001.png","chars_80EED7A6_002.png","chars_80EED7A6_003.png","chars_80EED7A6_004.png","chars_80EED7A6_005.png","chars_80EED7A6_006.png","chars_80EED7A6_007.png","chars_80EED7A6_008.png","chars_80EED7A6_009.png"],
              year_en_array: ["chars_80EED7A6_000.png","chars_80EED7A6_001.png","chars_80EED7A6_002.png","chars_80EED7A6_003.png","chars_80EED7A6_004.png","chars_80EED7A6_005.png","chars_80EED7A6_006.png","chars_80EED7A6_007.png","chars_80EED7A6_008.png","chars_80EED7A6_009.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 27,
              y: 261,
              week_en: ["chars_52EEE10_000.png","chars_52EEE10_001.png","chars_52EEE10_002.png","chars_52EEE10_003.png","chars_52EEE10_004.png","chars_52EEE10_005.png","chars_52EEE10_006.png"],
              week_tc: ["chars_52EEE10_000.png","chars_52EEE10_001.png","chars_52EEE10_002.png","chars_52EEE10_003.png","chars_52EEE10_004.png","chars_52EEE10_005.png","chars_52EEE10_006.png"],
              week_sc: ["chars_52EEE10_000.png","chars_52EEE10_001.png","chars_52EEE10_002.png","chars_52EEE10_003.png","chars_52EEE10_004.png","chars_52EEE10_005.png","chars_52EEE10_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 335,
              y: 164,
              src: 'bluetooth_3_b_33x33_h0s100b40.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 207,
              w: 1,
              h: 1,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 0,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 200,
              w: 1,
              h: 1,
              text: '',
              color: 0xFFFFFFFF,
              text_size: 0,
              press_src: 'trasparente.png',
              normal_src: 'trasparente.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}